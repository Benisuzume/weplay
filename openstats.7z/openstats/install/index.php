<?php
header('location: install.php');
?>