<?php
if (!isset($website) ) { header('HTTP/1.1 404 Not Found'); die; }
?>

<div class="clr"></div>
 <div class="ct-wrapper">
  <div class="outer-wrapper">
   <div class="content section">
    <div class="widget Blog">
     <div class="blog-posts hfeed">
    <h2><?=$lang["404_error"] ?></h2>
     </div>
    </div>
   </div>
  </div>
</div>

<div style="height: 400px;"></div>