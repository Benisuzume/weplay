<?php
if (!isset($website) ) { header('HTTP/1.1 404 Not Found'); die; }
?>

<div align="center" class="padTop padBottom">
    <h2><?=$lang["404_error"] ?></h2>
</div>