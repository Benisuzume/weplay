<?php
if (!isset($website) ) { header('HTTP/1.1 404 Not Found'); die; }
?>

<div class="entry clearfix" >
    <h2 class="title"><?=$lang["404_error"] ?></h2>
</div>

<div style="height: 400px;"></div>